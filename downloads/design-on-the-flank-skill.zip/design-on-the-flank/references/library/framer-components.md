<a id="top"></a>

# framer-components

Choose only the topic needed for the current request. Do not read every linked file.

Source: `framerlabs/skills/framer-code-components-overrides/SKILL.md`. Preserved reference examples; adapt them to the Framer contract.

| Topic | Lines |
|---|---:|
| [Framer Code Development](#01-framer-code-development) | 12 |
| [Code Components vs Code Overrides](#02-code-components-vs-code-overrides) | 6 |
| [Required Annotations](#03-required-annotations) | 16 |
| [Code Override Pattern](#04-code-override-pattern) | 19 |
| [Code Component Pattern](#05-code-component-pattern) | 25 |
| [Critical: Font Handling](#06-critical-font-handling) | 31 |
| [Critical: Wrap State Updates in startTransition](#07-critical-wrap-state-updates-in-starttransition) | 18 |
| [Critical: Hydration Safety](#08-critical-hydration-safety) | 24 |
| [Critical: Canvas vs Preview Detection](#09-critical-canvas-vs-preview-detection) | 16 |
| [Property Controls Reference](#10-property-controls-reference) | 4 |
| [Common Patterns](#11-common-patterns) | 4 |
| [Variant Control in Overrides](#12-variant-control-in-overrides) | 17 |
| [Scroll Detection Constraint](#13-scroll-detection-constraint) | 18 |
| [WebGL in Framer](#14-webgl-in-framer) | 4 |
| [Shadertoy to WebGL Conversion](#15-shadertoy-to-webgl-conversion) | 48 |
| [NPM Package Imports](#16-npm-package-imports) | 26 |
| [Common Pitfalls](#17-common-pitfalls) | 14 |
| [Mobile Optimization](#18-mobile-optimization) | 8 |
| [CMS Content Timing](#19-cms-content-timing) | 19 |
| [Text Manipulation in Overrides](#20-text-manipulation-in-overrides) | 22 |
| [Animation Best Practices](#21-animation-best-practices) | 22 |
| [Safari SVG Fix](#22-safari-svg-fix) | 11 |
| [Z-Index Stacking Context & React Portals](#23-z-index-stacking-context-react-portals) | 41 |
| [Loading States with Scroll Lock](#24-loading-states-with-scroll-lock) | 38 |
| [Easing Curves with Lerp Animations](#25-easing-curves-with-lerp-animations) | 64 |

---

<a id="01-framer-code-development"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
---
name: framer-code-components-overrides
description: Create Framer Code Components and Code Overrides. Use when building custom React components for Framer, writing Code Overrides (HOCs) to modify canvas elements, implementing property controls, working with Framer Motion animations, handling WebGL/shaders in Framer, or debugging Framer-specific issues like hydration errors and font handling.
user-invokable: true
license: MIT
metadata:
  author: fredm00n
  version: 1.0.0
---

# Framer Code Development


<!-- END SOURCE CONTENT -->

---

<a id="02-code-components-vs-code-overrides"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## Code Components vs Code Overrides

**Code Components**: Custom React components added to canvas. Support `addPropertyControls`.

**Code Overrides**: Higher-order components wrapping existing canvas elements. Do NOT support `addPropertyControls`.


<!-- END SOURCE CONTENT -->

---

<a id="03-required-annotations"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## Required Annotations

Always include at minimum:
```typescript
/**
 * @framerDisableUnlink
 * @framerIntrinsicWidth 100
 * @framerIntrinsicHeight 100
 */
```

Full set:
- `@framerDisableUnlink` — Prevents unlinking when modified
- `@framerIntrinsicWidth` / `@framerIntrinsicHeight` — Default dimensions
- `@framerSupportedLayoutWidth` / `@framerSupportedLayoutHeight` — `any`, `auto`, `fixed`, `any-prefer-fixed`


<!-- END SOURCE CONTENT -->

---

<a id="04-code-override-pattern"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## Code Override Pattern

```typescript
import type { ComponentType } from "react"
import { useState, useEffect } from "react"

/**
 * @framerDisableUnlink
 */
export function withFeatureName(Component): ComponentType {
    return (props) => {
        // State and logic here
        return <Component {...props} />
    }
}
```

Naming: Always use `withFeatureName` prefix.


<!-- END SOURCE CONTENT -->

---

<a id="05-code-component-pattern"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## Code Component Pattern

```typescript
import { motion } from "framer-motion"
import { addPropertyControls, ControlType } from "framer"

/**
 * @framerDisableUnlink
 * @framerIntrinsicWidth 300
 * @framerIntrinsicHeight 200
 */
export default function MyComponent(props) {
    const { style } = props
    return <motion.div style={{ ...style }}>{/* content */}</motion.div>
}

MyComponent.defaultProps = {
    // Always define defaults
}

addPropertyControls(MyComponent, {
    // Controls here
})
```


<!-- END SOURCE CONTENT -->

---

<a id="06-critical-font-handling"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## Critical: Font Handling

**Never access font properties individually. Always spread the entire font object.**

```typescript
// ❌ BROKEN - Will not work
style={{
    fontFamily: props.font.fontFamily,
    fontSize: props.font.fontSize,
}}

// ✅ CORRECT - Spread entire object
style={{
    ...props.font,
}}
```

Font control definition:
```typescript
font: {
    type: ControlType.Font,
    controls: "extended",
    defaultValue: {
        fontFamily: "Inter",
        fontWeight: 500,
        fontSize: 16,
        lineHeight: "1.5em",
    },
}
```


<!-- END SOURCE CONTENT -->

---

<a id="07-critical-wrap-state-updates-in-starttransition"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## Critical: Wrap State Updates in startTransition

All React state updates in Framer must be wrapped in `startTransition()`:

```typescript
import { startTransition } from "react"

// ❌ WRONG - May cause issues in Framer's rendering pipeline
setCount(count + 1)

// ✅ CORRECT - Always wrap state updates
startTransition(() => {
    setCount(count + 1)
})
```

This is Framer-specific and prevents performance issues with concurrent rendering.


<!-- END SOURCE CONTENT -->

---

<a id="08-critical-hydration-safety"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## Critical: Hydration Safety

Framer pre-renders on server. Browser APIs unavailable during SSR.

**Two-phase rendering pattern:**
```typescript
const [isClient, setIsClient] = useState(false)

useEffect(() => {
    setIsClient(true)
}, [])

if (!isClient) {
    return <Component {...props} /> // SSR-safe fallback
}

// Client-only logic here
```

**Never access directly at render time:**
- `window`, `document`, `navigator`
- `localStorage`, `sessionStorage`
- `window.innerWidth`, `window.innerHeight`


<!-- END SOURCE CONTENT -->

---

<a id="09-critical-canvas-vs-preview-detection"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## Critical: Canvas vs Preview Detection

```typescript
import { RenderTarget } from "framer"

const isOnCanvas = RenderTarget.current() === RenderTarget.canvas

// Show debug only in editor
{isOnCanvas && <DebugOverlay />}
```

Use for:
- Debug overlays
- Disabling heavy effects in editor
- Preview toggles


<!-- END SOURCE CONTENT -->

---

<a id="10-property-controls-reference"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## Property Controls Reference

See [references/property-controls.md](framer-components-property-controls.md) for complete control types and patterns.


<!-- END SOURCE CONTENT -->

---

<a id="11-common-patterns"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## Common Patterns

See [references/patterns.md](framer-components-patterns.md) for implementations: shared state, keyboard detection, show-once logic, scroll effects, magnetic hover, animation triggers.


<!-- END SOURCE CONTENT -->

---

<a id="12-variant-control-in-overrides"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## Variant Control in Overrides

Cannot read variant names from props (may be hashed). Manage internally:

```typescript
export function withVariantControl(Component): ComponentType {
    return (props) => {
        const [currentVariant, setCurrentVariant] = useState("variant-1")

        // Logic to change variant
        setCurrentVariant("variant-2")

        return <Component {...props} variant={currentVariant} />
    }
}
```


<!-- END SOURCE CONTENT -->

---

<a id="13-scroll-detection-constraint"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## Scroll Detection Constraint

Framer's scroll detection uses viewport-based IntersectionObserver. Applying `overflow: scroll` to containers breaks this detection.

For scroll-triggered animations, use:
```typescript
const observer = new IntersectionObserver(
    (entries) => {
        entries.forEach((entry) => {
            if (entry.isIntersecting && !hasEntered) {
                setHasEntered(true)
            }
        })
    },
    { threshold: 0.1 }
)
```


<!-- END SOURCE CONTENT -->

---

<a id="14-webgl-in-framer"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## WebGL in Framer

See [references/webgl-shaders.md](framer-components-webgl-shaders.md) for shader implementation patterns including transparency handling.


<!-- END SOURCE CONTENT -->

---

<a id="15-shadertoy-to-webgl-conversion"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## Shadertoy to WebGL Conversion

When adapting complex Shadertoy algorithms (GLSL) into Framer React Code Components using raw WebGL 1.0, you must handle several strict limitations:

### 1. WebGL 1.0 Syntax Limitations
**No `tanh()`**: WebGL 1.0 doesn't have a native hyperbolic tangent. Use an exponential approximation and clamp to prevent overflow/NaN (which causes black screens):
```glsl
vec4 tanh_approx(vec4 x) {
    vec4 x_clamped = clamp(x, -20.0, 20.0);
    vec4 exp2x = exp(2.0 * x_clamped);
    return (exp2x - 1.0) / (exp2x + 1.0);
}
```

**Strict Typing**: WebGL 1.0 does not auto-cast. You cannot mix floats and ints (e.g., `1` vs `1.0`).

**For-Loops**: WebGL 1.0 requires loop indices to be compared to a constant expression. You cannot mutate the iterator in complex ways inside the loop header (e.g., `for(o*=i; i++<1e2; ...)` will fail). Extract logic cleanly:
```glsl
// ❌ Shadertoy shortcut (Fails in WebGL 1.0)
for(o*=i; i++<1e2; p += cos(...)) { ... }

// ✅ WebGL 1.0 compliant
float i = 0.0;
for(int j = 0; j < 100; j++) {
    i += 1.0;
    float fi = float(j);
    // ... Math logic here ...
}
```

### 2. Framer Canvas vs Published (Performance Drop)
Shaders iterate per pixel. A loop of 100 iterations on a 4K retina screen (DPR 2.0) will instantly freeze Framer's editor because it executes millions of calculations per frame.

**Solution:** Clamp Device Pixel Ratio (`dpr`) to preserve framerate, and disable time-based animations on Canvas:
```typescript
// Inside render() function
// Downscale high-density screens for complex shaders (e.g., limit to 0.75 or 1.0)
const dpr = window.devicePixelRatio > 1.5 ? 1.0 : window.devicePixelRatio

if (canvas.width !== Math.floor(displayWidth * dpr)) {
    canvas.width = Math.floor(displayWidth * dpr)
    canvas.height = Math.floor(displayHeight * dpr)
}

// Stop heavy time calculations in Editor to keep Canvas snappy
const currentTime = isOnCanvas ? 0 : (performance.now() - startTime) * 0.001 * speed
```


<!-- END SOURCE CONTENT -->

---

<a id="16-npm-package-imports"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## NPM Package Imports

Standard import (preferred):
```typescript
import { Component } from "package-name"
```

Force specific version via CDN when Framer cache is stuck:
```typescript
import { Component } from "https://esm.sh/package-name@1.2.3?external=react,react-dom"
```

Always include `?external=react,react-dom` for React components.

**Critical for Three.js in Framer:**
Framer's SSR environment **does not support** Node.js `require()` for Three.js addon modules (like `EffectComposer` or `GLTFLoader`). You must import them via `esm.sh` and set `?external=three` to prevent duplicate Three.js instances:

```typescript
// ❌ FAILS IN FRAMER:
// const EffectComposer = require("three/examples/jsm/postprocessing/EffectComposer.js")

// ✅ CORRECT:
import { EffectComposer } from "https://esm.sh/three@0.160.0/examples/jsm/postprocessing/EffectComposer.js?external=three"
import { RenderPass } from "https://esm.sh/three@0.160.0/examples/jsm/postprocessing/RenderPass.js?external=three"
```


<!-- END SOURCE CONTENT -->

---

<a id="17-common-pitfalls"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## Common Pitfalls

| Issue | Cause | Fix |
|-------|-------|-----|
| Font styles not applying | Accessing font props individually | Spread entire font object: `...props.font` |
| Hydration mismatch | Browser API in render | Use `isClient` state pattern |
| Override props undefined | Expecting property controls | Overrides don't support `addPropertyControls` |
| Scroll animation broken | `overflow: scroll` on container | Use IntersectionObserver on viewport |
| Shader attach error | Null shader from compilation failure | Check `createShader()` return before `attachShader()` |
| Component display name | Need custom name in Framer UI | `Component.displayName = "Name"` |
| TypeScript `Timeout` errors | Using `NodeJS.Timeout` type | Use `number` instead — browser environment |
| Overlay stuck under content | Stacking context from parent | Use React Portal to render at `document.body` level |
| Easing feels same for all curves | Not tracking initial distance | Track `initialDiff` when target changes for progress calculation |


<!-- END SOURCE CONTENT -->

---

<a id="18-mobile-optimization"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## Mobile Optimization

For particle systems and heavy animations:
- Implement resize debouncing (500ms default)
- Add size change threshold (15% minimum)
- Handle orientation changes with dedicated listener
- Use `touchAction: "none"` to prevent scroll interference


<!-- END SOURCE CONTENT -->

---

<a id="19-cms-content-timing"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## CMS Content Timing

CMS content loads asynchronously after hydration. Processing sequence:
1. SSR: Placeholder content
2. Hydration: React attaches
3. CMS Load: Real content (~50-200ms)

Add delay before processing CMS data:
```typescript
useEffect(() => {
    if (isClient && props.children) {
        const timer = setTimeout(() => {
            processContent(props.children)
        }, 100)
        return () => clearTimeout(timer)
    }
}, [isClient, props.children])
```


<!-- END SOURCE CONTENT -->

---

<a id="20-text-manipulation-in-overrides"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## Text Manipulation in Overrides

Framer text uses deeply nested structure. Process recursively:

```typescript
const processChildren = (children) => {
    if (typeof children === "string") {
        return processText(children)
    }
    if (isValidElement(children)) {
        return cloneElement(children, {
            ...children.props,
            children: processChildren(children.props.children)
        })
    }
    if (Array.isArray(children)) {
        return children.map(child => processChildren(child))
    }
    return children
}
```


<!-- END SOURCE CONTENT -->

---

<a id="21-animation-best-practices"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## Animation Best Practices

**Separate positioning from animation:**
```typescript
<motion.div
    style={{
        position: "absolute",
        left: `${offset}px`,  // Static positioning
        x: animatedValue,     // Animation transform
    }}
/>
```

**Split animation phases for natural motion:**
```typescript
// Up: snappy pop
transition={{ duration: 0.15, ease: [0, 0, 0.39, 2.99] }}

// Down: smooth settle
transition={{ duration: 0.15, ease: [0.25, 0.46, 0.45, 0.94] }}
```


<!-- END SOURCE CONTENT -->

---

<a id="22-safari-svg-fix"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## Safari SVG Fix

Force GPU acceleration for smooth SVG animations:
```typescript
style={{
    willChange: "transform",
    transform: "translateZ(0)",
    backfaceVisibility: "hidden",
}}
```


<!-- END SOURCE CONTENT -->

---

<a id="23-z-index-stacking-context-react-portals"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## Z-Index Stacking Context & React Portals

**Problem:** Components with `position: absolute` inherit their parent's stacking context. Even with `z-index: 9999`, they can't appear above elements outside the parent.

**Solution:** Use React Portal to render at `document.body` level:

```typescript
import { createPortal } from "react-dom"

export default function ComponentWithOverlay(props) {
    const [showOverlay, setShowOverlay] = useState(false)

    return (
        <div style={{ position: "relative" }}>
            {/* Main component content */}

            {/* Overlay rendered outside parent hierarchy */}
            {showOverlay && createPortal(
                <div style={{
                    position: "fixed",  // Fixed to viewport
                    inset: 0,
                    zIndex: 9999,
                    background: "rgba(0, 0, 0, 0.8)",
                }}>
                    {/* Overlay content */}
                </div>,
                document.body
            )}
        </div>
    )
}
```

**Key differences:**
- `position: "fixed"` positions relative to viewport, not parent
- Portal breaks out of component's DOM hierarchy and stacking context
- Works for modals, tooltips, popovers, loading overlays

**Canvas vs Published:**
Portals work in both canvas editor and published site. No RenderTarget check needed.


<!-- END SOURCE CONTENT -->

---

<a id="24-loading-states-with-scroll-lock"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## Loading States with Scroll Lock

**Pattern:** Show loading overlay and prevent page scroll until content is ready.

```typescript
const [isLoading, setIsLoading] = useState(true)
const [fadeOut, setFadeOut] = useState(false)

// Prevent scroll while loading (published site only)
useEffect(() => {
    const isPublished = RenderTarget.current() !== "CANVAS"
    if (!isPublished || !isLoading) return

    const originalOverflow = document.body.style.overflow
    document.body.style.overflow = "hidden"

    return () => {
        document.body.style.overflow = originalOverflow
    }
}, [isLoading])

// Two-phase hide: fade-out → remove from DOM
const hideLoader = () => {
    setFadeOut(true)
    setTimeout(() => setIsLoading(false), 300) // Match CSS transition
}
```

**Scroll to top on load** (fixes variant sequence issues):
```typescript
useEffect(() => {
    const isPublished = RenderTarget.current() !== "CANVAS"
    if (isPublished) {
        window.scrollTo(0, 0)
    }
}, [])
```


<!-- END SOURCE CONTENT -->

---

<a id="25-easing-curves-with-lerp-animations"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## Easing Curves with Lerp Animations

**Problem:** Exponential lerp (`value += diff * speed`) naturally gives ease-out. Need to track initial distance to implement other curves.

**Solution:** Track `initialDiff` when animation starts:

```typescript
const animated = useRef({
    property: {
        current: 0,
        target: 0,
        initialDiff: 0,  // Track for easing calculations
    }
})

// When target changes, store initial distance
const updateTarget = (newTarget) => {
    const entry = animated.current.property
    entry.initialDiff = Math.abs(newTarget - entry.current)
    entry.target = newTarget
}

// Apply easing in animation loop
const applyEasing = (easingCurve) => {
    const v = animated.current.property
    const diff = v.target - v.current
    let speed = 0.05  // Base speed

    if (easingCurve !== "ease-out") {
        // Calculate progress: 0 at start, 1 near target
        const diffMagnitude = Math.abs(diff)
        const progress = v.initialDiff > 0
            ? Math.max(0, Math.min(1, 1 - (diffMagnitude / v.initialDiff)))
            : 1

        if (easingCurve === "ease-in") {
            // Start slow, end fast (cubic)
            speed *= (0.05 + Math.pow(progress, 3) * 10)
        } else if (easingCurve === "ease-in-out") {
            // Slow-fast-slow (smootherstep)
            const smoothed = progress * progress * progress *
                (progress * (progress * 6 - 15) + 10)
            speed *= (0.2 + smoothed * 3)
        }
    }
    // ease-out: use default exponential decay

    v.current += diff * speed
}
```

**Why aggressive curves?**
Exponential lerp naturally slows down approaching target. To create noticeable ease-in, need extreme multipliers (0.05x → 10x) to overcome the natural decay.

**Property control:**
```typescript
easingCurve: {
    type: ControlType.Enum,
    title: "Easing Curve",
    options: ["ease-out", "ease-in", "ease-in-out"],
    optionTitles: ["Ease Out", "Ease In", "Ease In/Out"],
    defaultValue: "ease-out",
}
```

<!-- END SOURCE CONTENT -->
