<a id="top"></a>

# framer-components-property-controls

Choose only the topic needed for the current request. Do not read every linked file.

Source: `framerlabs/skills/framer-code-components-overrides/references/property-controls.md`. Preserved reference examples; adapt them to the Framer contract.

| Topic | Lines |
|---|---:|
| [Property Controls Reference](#01-property-controls-reference) | 2 |
| [Control Types](#02-control-types) | 2 |
| [String](#03-string) | 14 |
| [Number](#04-number) | 14 |
| [Boolean](#05-boolean) | 11 |
| [Color](#06-color) | 9 |
| [Enum (Dropdown or Segmented)](#07-enum-dropdown-or-segmented) | 12 |
| [Image](#08-image) | 10 |
| [ResponsiveImage / File — No defaultValue Support](#09-responsiveimage-file-no-defaultvalue-support) | 41 |
| [File](#10-file) | 9 |
| [Font (Extended)](#11-font-extended) | 44 |
| [Transition](#12-transition) | 9 |
| [ComponentInstance](#13-componentinstance) | 10 |
| [Array](#14-array) | 12 |
| [Array with Image Preview](#15-array-with-image-preview) | 16 |
| [Object (Grouped Controls)](#16-object-grouped-controls) | 15 |
| [Conditional Visibility](#17-conditional-visibility) | 15 |
| [Markdown Descriptions](#18-markdown-descriptions) | 9 |
| [Default Props Requirement](#19-default-props-requirement) | 19 |
| [Common Patterns](#20-common-patterns) | 42 |

---

<a id="01-property-controls-reference"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
# Property Controls Reference


<!-- END SOURCE CONTENT -->

---

<a id="02-control-types"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## Control Types


<!-- END SOURCE CONTENT -->

---

<a id="03-string"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
### String
```typescript
text: {
    type: ControlType.String,
    title: "Text",
    defaultValue: "Hello",
    placeholder: "Enter text...",
    displayTextArea: true, // For multiline
    preventLocalization: true, // Prevents automatic translation
}
```

Use `preventLocalization: true` for technical content that shouldn't be translated (API keys, code snippets, etc.).


<!-- END SOURCE CONTENT -->

---

<a id="04-number"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
### Number
```typescript
value: {
    type: ControlType.Number,
    title: "Value",
    defaultValue: 50,
    min: 0,
    max: 100,
    step: 1,
    unit: "px",
    displayStepper: true,
}
```


<!-- END SOURCE CONTENT -->

---

<a id="05-boolean"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
### Boolean
```typescript
enabled: {
    type: ControlType.Boolean,
    title: "Enabled",
    defaultValue: true,
    enabledTitle: "On",
    disabledTitle: "Off",
}
```


<!-- END SOURCE CONTENT -->

---

<a id="06-color"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
### Color
```typescript
color: {
    type: ControlType.Color,
    title: "Color",
    defaultValue: "#09f",
}
```


<!-- END SOURCE CONTENT -->

---

<a id="07-enum-dropdown-or-segmented"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
### Enum (Dropdown or Segmented)
```typescript
mode: {
    type: ControlType.Enum,
    title: "Mode",
    defaultValue: "auto",
    options: ["auto", "manual", "disabled"],
    optionTitles: ["Auto", "Manual", "Disabled"],
    displaySegmentedControl: true, // false for dropdown
}
```


<!-- END SOURCE CONTENT -->

---

<a id="08-image"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
### Image
```typescript
image: {
    type: ControlType.Image,
    title: "Image",
}
```

Returns URL string. For previews in the control panel, use `ControlType.ResponsiveImage`.


<!-- END SOURCE CONTENT -->

---

<a id="09-responsiveimage-file-no-defaultvalue-support"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
### ResponsiveImage / File — No defaultValue Support

**Critical**: `ControlType.ResponsiveImage` and `ControlType.File` do NOT support `defaultValue` in property controls. You must use component parameter destructuring instead:

```typescript
// ❌ WRONG - defaultValue is ignored
addPropertyControls(MyComponent, {
    image: {
        type: ControlType.ResponsiveImage,
        defaultValue: { src: "...", alt: "..." }, // This does nothing!
    },
})

// ✅ CORRECT - Use parameter destructuring
function MyComponent(props) {
    const {
        image = {
            src: "https://framerusercontent.com/images/GfGkADagM4KEibNcIiRUWlfrR0.jpg",
            alt: "Default image"
        }
    } = props

    return <img {...image} />
}

addPropertyControls(MyComponent, {
    image: { type: ControlType.ResponsiveImage },
})
```

Same pattern applies to `ControlType.File`:
```typescript
function MyComponent(props) {
    const {
        videoFile = "https://framerusercontent.com/assets/MLWPbW1dUQawJLhhun3dBwpgJak.mp4"
    } = props

    return <video src={videoFile} />
}
```


<!-- END SOURCE CONTENT -->

---

<a id="10-file"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
### File
```typescript
video: {
    type: ControlType.File,
    title: "Video",
    allowedFileTypes: ["mp4", "webm"],
}
```


<!-- END SOURCE CONTENT -->

---

<a id="11-font-extended"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
### Font (Extended)
```typescript
font: {
    type: ControlType.Font,
    title: "Font",
    controls: "extended",
    defaultValue: {
        fontFamily: "Inter",
        fontWeight: 500,
        fontSize: 16,
        lineHeight: "1.5em",
    },
}
```

**Critical**: Always spread the entire font object in styles: `...props.font`

#### Variant-to-FontWeight Mapping

Framer uses `variant` names that map to CSS `font-weight` and `font-style`:

| Variant | font-weight | font-style |
|---------|-------------|------------|
| Thin | 100 | normal |
| Extra Light | 200 | normal |
| Light | 300 | normal |
| Regular | 400 | normal |
| Medium | 500 | normal |
| Semibold | 600 | normal |
| Bold | 700 | normal |
| Extra Bold | 800 | normal |
| Black | 900 | normal |
| Thin Italic | 100 | italic |
| Extra Light Italic | 200 | italic |
| Light Italic | 300 | italic |
| Italic / Regular Italic | 400 | italic |
| Medium Italic | 500 | italic |
| Semibold Italic | 600 | italic |
| Bold Italic | 700 | italic |
| Extra Bold Italic | 800 | italic |
| Black Italic | 900 | italic |

Use these variant names in `defaultValue.variant` when setting up Font controls.


<!-- END SOURCE CONTENT -->

---

<a id="12-transition"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
### Transition
```typescript
transition: {
    type: ControlType.Transition,
    title: "Transition",
    defaultValue: { duration: 0.5 },
}
```


<!-- END SOURCE CONTENT -->

---

<a id="13-componentinstance"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
### ComponentInstance
```typescript
icon: {
    type: ControlType.ComponentInstance,
    title: "Icon",
}
```

Accepts a component from the canvas.


<!-- END SOURCE CONTENT -->

---

<a id="14-array"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
### Array
```typescript
items: {
    type: ControlType.Array,
    title: "Items",
    maxCount: 10,
    control: {
        type: ControlType.String,
    },
}
```


<!-- END SOURCE CONTENT -->

---

<a id="15-array-with-image-preview"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
### Array with Image Preview
```typescript
images: {
    type: ControlType.Array,
    title: "Images",
    control: {
        type: ControlType.Object,
        controls: {
            image: {
                type: ControlType.ResponsiveImage,
            },
        },
    },
}
```


<!-- END SOURCE CONTENT -->

---

<a id="16-object-grouped-controls"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
### Object (Grouped Controls)
```typescript
settings: {
    type: ControlType.Object,
    title: "Settings",
    icon: "effect", // UI icon: "object" | "effect" | "color" | "interaction" | "boolean"
    controls: {
        opacity: { type: ControlType.Number, defaultValue: 1 },
        color: { type: ControlType.Color, defaultValue: "#fff" },
    },
}
```

The `icon` property changes how the control appears in Framer's property panel. Options: `"object"`, `"effect"`, `"color"`, `"interaction"`, `"boolean"`.


<!-- END SOURCE CONTENT -->

---

<a id="17-conditional-visibility"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## Conditional Visibility

Hide controls based on other prop values:

```typescript
advancedMode: {
    type: ControlType.Boolean,
    defaultValue: false,
},
advancedSetting: {
    type: ControlType.Number,
    hidden: (props) => !props.advancedMode,
},
```


<!-- END SOURCE CONTENT -->

---

<a id="18-markdown-descriptions"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## Markdown Descriptions

```typescript
setting: {
    type: ControlType.Number,
    description: "Controls the *intensity*.\n\n[Learn more](https://example.com)",
}
```


<!-- END SOURCE CONTENT -->

---

<a id="19-default-props-requirement"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## Default Props Requirement

Property Controls only affect canvas. Always define `defaultProps` for:
- Preventing runtime errors
- Components instantiated from code
- Initial render before controls apply

```typescript
MyComponent.defaultProps = {
    text: "Default",
    color: "#000",
    font: {
        fontFamily: "Inter",
        fontWeight: 500,
        fontSize: 16,
    },
}
```


<!-- END SOURCE CONTENT -->

---

<a id="20-common-patterns"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## Common Patterns

### Mode-Dependent Controls
```typescript
addPropertyControls(Component, {
    mode: {
        type: ControlType.Enum,
        options: ["image", "video"],
        defaultValue: "image",
    },
    image: {
        type: ControlType.Image,
        hidden: (props) => props.mode !== "image",
    },
    video: {
        type: ControlType.File,
        allowedFileTypes: ["mp4"],
        hidden: (props) => props.mode !== "video",
    },
})
```

### Nested Object with Conditional
```typescript
progressOptions: {
    type: ControlType.Object,
    title: "Progress",
    controls: {
        showProgress: {
            type: ControlType.Boolean,
            defaultValue: false,
        },
        progressFont: {
            type: ControlType.Font,
            controls: "extended",
            hidden: (props) => !props.showProgress,
        },
    },
}
```

Note: In nested objects, `hidden` receives the parent object, not root props.

<!-- END SOURCE CONTENT -->
