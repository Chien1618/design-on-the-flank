<a id="top"></a>

# framer-plugins-api-reference

Choose only the topic needed for the current request. Do not read every linked file.

Source: `framerlabs/skills/framer-plugins/references/api-reference.md`. Preserved reference examples; adapt them to the Framer contract.

| Topic | Lines |
|---|---:|
| [Framer Plugin API Reference](#01-framer-plugin-api-reference) | 4 |
| [framer Global Object](#02-framer-global-object) | 127 |
| [ManagedCollection](#03-managedcollection) | 31 |
| [ManagedCollectionFieldInput](#04-managedcollectionfieldinput) | 42 |
| [ManagedCollectionItemInput](#05-managedcollectioniteminput) | 13 |
| [FieldDataEntryInput — All Type Variants](#06-fielddataentryinput-all-type-variants) | 68 |
| [Collection (Non-Managed)](#07-collection-non-managed) | 19 |
| [ProtectedMethod — Known Values](#08-protectedmethod-known-values) | 25 |
| [React Hooks](#09-react-hooks) | 14 |
| [Error Handling](#10-error-handling) | 18 |
| [Official Documentation URLs](#11-official-documentation-urls) | 13 |

---

<a id="01-framer-plugin-api-reference"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
# Framer Plugin API Reference

Detailed API documentation for the `framer-plugin` SDK. For a concise overview, see [SKILL.md](framer-plugins.md).


<!-- END SOURCE CONTENT -->

---

<a id="02-framer-global-object"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## framer Global Object

### Mode & Identity

```typescript
framer.mode: string                    // Current plugin mode
framer.getProjectInfo(): Promise<{ id: string; name: string }>
```

### UI Management

```typescript
framer.showUI(options?: {
    position?: "center" | "top left" | "bottom left" | "top right" | "bottom right"
    width?: number
    height?: number
    minWidth?: number
    minHeight?: number
    maxWidth?: number
    maxHeight?: number
    resizable?: boolean | "width" | "height"
}): Promise<void>

framer.hideUI(): Promise<void>

framer.closePlugin(message?: string, options?: {
    variant?: "success" | "info" | "error"
}): never
// Throws FramerPluginClosedError internally. Code after this never executes.

framer.notify(message: string, options?: {
    variant?: "info" | "success" | "warning" | "error"
    durationMs?: number | typeof Infinity
    button?: { text: string; onClick: () => void }
}): void

framer.setCloseWarning(message: string | false): Promise<void>
// Show confirmation dialog when user tries to close plugin during operations.

framer.setBackgroundMessage(message: string): void
// Status text shown while plugin UI is hidden.

framer.setMenu(items: Array<
    | { label: string; onAction: () => void; visible?: boolean }
    | { type: "separator" }
>): void
```

### Collection Access

```typescript
framer.getActiveManagedCollection(): Promise<ManagedCollection>
framer.getActiveCollection(): Promise<Collection>
framer.getManagedCollections(): Promise<ManagedCollection[]>
framer.getCollections(): Promise<Collection[]>
framer.createManagedCollection(): Promise<ManagedCollection>
```

### Canvas / Node Methods

```typescript
framer.addImage(options: {
    image: string        // URL
    name?: string
    altText?: string
}): Promise<void>

framer.setImage(options: {
    image: string
    name?: string
    altText?: string
}): Promise<void>

framer.getImage(): Promise<{ image: string; altText?: string } | null>

framer.addText(text: string): Promise<void>
framer.addFrame(): Promise<void>
framer.addSVG(svg: string, name?: string): Promise<void>  // max 10kB
framer.addComponentInstance(options: {
    url: string
    attributes?: Record<string, unknown>
}): Promise<void>

framer.getSelection(): Promise<Node[]>
framer.subscribeToSelection(callback: (selection: Node[]) => void): () => void
framer.subscribeToCanvasRoot(callback: (root: Node) => void): () => void
```

### Project-Level Plugin Data

```typescript
framer.setPluginData(key: string, value: string | null): Promise<void>
// Pass null to delete. 2kB per entry, 4kB total across all keys.

framer.getPluginData(key: string): Promise<string | null>
```

### Permissions

```typescript
framer.isAllowedTo(...methods: ProtectedMethod[]): boolean
// Synchronous check. Returns true if ALL methods are allowed.

framer.subscribeToIsAllowedTo(
    callback: (isAllowed: boolean) => void,
    ...methods: ProtectedMethod[]
): () => void
```

### Draggable Component

```typescript
import { Draggable } from "framer-plugin"

<Draggable data={{
    type: "image",
    image: "https://...",
    previewImage: "https://...",
    name: "Photo",
    altText: "Description",
}}>
    <div>Drag me</div>
</Draggable>
```

---


<!-- END SOURCE CONTENT -->

---

<a id="03-managedcollection"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## ManagedCollection

```typescript
interface ManagedCollection {
    id: string
    name: string

    // Items
    getItemIds(): Promise<string[]>
    addItems(items: ManagedCollectionItemInput[]): Promise<void>
    // Upsert: adds new items, updates existing items matched by id.
    removeItems(ids: string[]): Promise<void>
    setItemOrder(ids: string[]): Promise<void>

    // Fields
    getFields(): Promise<ManagedCollectionField[]>
    setFields(fields: ManagedCollectionFieldInput[]): Promise<void>
    // Replaces the entire field schema. Existing data for removed fields is lost.

    // Plugin Data (per-collection)
    setPluginData(key: string, value: string | null): Promise<void>
    getPluginData(key: string): Promise<string | null>
    // 2kB per entry, 4kB per collection. Strings only.

    // Activation
    setAsActive(): Promise<void>  // SDK 2.2.0+
}
```

---


<!-- END SOURCE CONTENT -->

---

<a id="04-managedcollectionfieldinput"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## ManagedCollectionFieldInput

```typescript
interface ManagedCollectionFieldInput {
    id: string                              // Stable identifier, used in fieldData keys
    name: string                            // Display name in Framer CMS
    type: CollectionFieldType
    userEditable?: boolean                  // Default false for managed collections.
                                            // If true, user can edit this field in CMS UI
                                            // and sync won't overwrite it.

    // Type-specific properties:
    cases?: { id: string; name: string }[]  // Required for "enum"
    collectionId?: string                   // Required for "collectionReference" / "multiCollectionReference"
    allowedFileTypes?: string[]             // Optional for "file"
    fields?: ManagedCollectionFieldInput[]  // Required for "array" (gallery sub-fields)
}
```

### CollectionFieldType — All Values

```typescript
type CollectionFieldType =
    | "boolean"
    | "color"
    | "number"
    | "string"
    | "formattedText"
    | "image"
    | "file"
    | "link"
    | "date"
    | "enum"
    | "collectionReference"
    | "multiCollectionReference"
    | "array"
    | "divider"
    | "unsupported"
```

---


<!-- END SOURCE CONTENT -->

---

<a id="05-managedcollectioniteminput"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## ManagedCollectionItemInput

```typescript
interface ManagedCollectionItemInput {
    id: string                                      // Unique item identifier (used for upsert matching)
    slug: string                                    // URL slug, must be unique across collection
    draft: boolean                                  // true = draft, false = published
    fieldData: Record<string, FieldDataEntryInput>  // Keys are field IDs
}
```

---


<!-- END SOURCE CONTENT -->

---

<a id="06-fielddataentryinput-all-type-variants"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## FieldDataEntryInput — All Type Variants

Every field value must explicitly declare its type. Never pass raw values.

```typescript
// Primitives
{ type: "string", value: string }
{ type: "number", value: number }
{ type: "boolean", value: boolean }

// Date — ISO 8601 string
{ type: "date", value: string | null }
// Example: "2024-06-15T10:30:00Z"

// Link — full URL
{ type: "link", value: string | null }

// Image — URL string or null
{ type: "image", value: string | null }

// File — URL string or null
{ type: "file", value: string | null }

// Color — hex string or null
{ type: "color", value: string | null }

// Formatted Text — HTML content
{ type: "formattedText", value: string, contentType?: "html" }

// Enum — value is the case ID (not display name)
{ type: "enum", value: string }

// Collection Reference — value is an item ID or slug from the referenced collection
{ type: "collectionReference", value: string }

// Multi Collection Reference — array of item IDs/slugs
{ type: "multiCollectionReference", value: string[] }

// Array (Gallery) — nested items with their own fieldData
{ type: "array", value: ArrayItemInput[] }
```

### ArrayItemInput (for gallery/array fields)

```typescript
interface ArrayItemInput {
    id: string
    fieldData: Record<string, FieldDataEntryInput>
}
```

### Default Values for Missing Fields

When a source item has no data for a field, use type-appropriate defaults:

| Type | Default |
|------|---------|
| `string`, `formattedText` | `""` |
| `boolean` | `false` |
| `number` | `0` |
| `image`, `file`, `link`, `date`, `color` | `null` |
| `collectionReference` | `null` |
| `multiCollectionReference` | `[]` |
| `array` | `[]` |
| `enum` | First case ID |

---


<!-- END SOURCE CONTENT -->

---

<a id="07-collection-non-managed"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## Collection (Non-Managed)

For collections not owned by the plugin (user-editable collections):

```typescript
interface Collection {
    id: string
    name: string
    managedBy: "user" | string     // "user" for unmanaged, plugin ID for managed
    addFields(fields: CollectionFieldInput[]): Promise<void>
    addItems(items: CollectionItemInput[]): Promise<void>
    // ... other methods
}
```

Use `framer.getActiveCollection()` for the `collection` mode.

---


<!-- END SOURCE CONTENT -->

---

<a id="08-protectedmethod-known-values"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## ProtectedMethod — Known Values

```typescript
type ProtectedMethod =
    // ManagedCollection
    | "ManagedCollection.addItems"
    | "ManagedCollection.removeItems"
    | "ManagedCollection.setFields"
    | "ManagedCollection.setPluginData"
    // Collection (non-managed)
    | "Collection.addItems"
    | "Collection.addFields"
    | "Collection.removeFields"
    // Nodes
    | "Node.setAttributes"
    // Canvas
    | "addImage"
    | "setImage"
    | "addText"
```

"Get" methods (getItemIds, getFields, getPluginData, etc.) do NOT require permission checks.

---


<!-- END SOURCE CONTENT -->

---

<a id="09-react-hooks"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## React Hooks

```typescript
import { useIsAllowedTo } from "framer-plugin"

// Reactive permission check — re-renders when permissions change
const canSync: boolean = useIsAllowedTo(
    "ManagedCollection.addItems",
    "ManagedCollection.removeItems"
)
```

---


<!-- END SOURCE CONTENT -->

---

<a id="10-error-handling"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## Error Handling

```typescript
import { FramerPluginClosedError } from "framer-plugin"

try {
    await syncCollection(collection)
    framer.closePlugin("Sync complete", { variant: "success" })
} catch (error) {
    if (error instanceof FramerPluginClosedError) return  // User closed plugin, ignore
    framer.notify(error.message, { variant: "error" })
}
```

The SDK auto-suppresses unhandled `FramerPluginClosedError` rejections. If you have a catch block that handles errors generically, explicitly check for and ignore this class.

---


<!-- END SOURCE CONTENT -->

---

<a id="11-official-documentation-urls"></a>

Source excerpt. Read the package Framer integration rules before adapting code.

<!-- BEGIN SOURCE CONTENT -->
## Official Documentation URLs

- [Reference](https://www.framer.com/developers/reference)
- [CMS / Managed Collections](https://www.framer.com/developers/cms)
- [Plugin Modes](https://www.framer.com/developers/modes)
- [Interface / showUI](https://www.framer.com/developers/interface)
- [Permissions](https://www.framer.com/developers/plugins-permissions)
- [Data Storage](https://www.framer.com/developers/storing-data)
- [Nodes](https://www.framer.com/developers/nodes)
- [Configuration / framer.json](https://www.framer.com/developers/configuration)
- [Publishing](https://www.framer.com/developers/publishing)
- [Quick Start](https://www.framer.com/developers/plugins-quick-start)
- [Changelog](https://www.framer.com/developers/changelog)

<!-- END SOURCE CONTENT -->
