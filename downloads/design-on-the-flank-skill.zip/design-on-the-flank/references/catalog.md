# Topic catalog

Read one index, then the relevant topic files. Open additional topics only when the task calls for them. The source manifest is for maintainers, not task context.

Start with the [Framer contract](framer-contract.md); for animation or 3D also read [integration rules](advanced-integration.md).

<a id="framer"></a>
## Framer

| Module | Use for |
|---|---|
| [framer-components](library/framer-components.md) | Components, overrides, layout and rendering |
| [framer-components-property-controls](library/framer-components-property-controls.md) | Editable props, control types and defaults |
| [framer-components-patterns](library/framer-components-patterns.md) | Component patterns and integration examples |
| [framer-components-webgl-shaders](library/framer-components-webgl-shaders.md) | Framer shader and canvas patterns |

<a id="threejs"></a>
## Three.js

| Module | Use for |
|---|---|
| [threejs-animation](library/threejs-animation.md) | Keyframes, mixers, morphs and procedural animation |
| [threejs-fundamentals](library/threejs-fundamentals.md) | Scene, camera, renderer and object hierarchy |
| [threejs-geometry](library/threejs-geometry.md) | Shapes, custom buffers, particles and instancing |
| [threejs-interaction](library/threejs-interaction.md) | Raycasting, pointers and controls |
| [threejs-lighting](library/threejs-lighting.md) | Lights, shadows and environment lighting |
| [threejs-loaders](library/threejs-loaders.md) | Models, textures and asynchronous assets |
| [threejs-materials](library/threejs-materials.md) | PBR, material properties and custom materials |
| [threejs-postprocessing](library/threejs-postprocessing.md) | Composer, bloom and screen effects |
| [threejs-shaders](library/threejs-shaders.md) | GLSL, uniforms and shader effects |
| [threejs-textures](library/threejs-textures.md) | UVs, textures and environment maps |

<a id="gsap"></a>
## GSAP

| Module | Use for |
|---|---|
| [gsap-core](library/gsap-core.md) | Tweens, easing, transforms and lifecycle |
| [gsap-frameworks](library/gsap-frameworks.md) | Other frameworks; only read when specifically needed |
| [gsap-performance](library/gsap-performance.md) | Rendering cost and animation performance |
| [gsap-plugins](library/gsap-plugins.md) | SplitText, Flip, Draggable, MotionPath and other plugins |
| [gsap-react](library/gsap-react.md) | React hooks, scoped context and cleanup |
| [gsap-scrolltrigger](library/gsap-scrolltrigger.md) | Scroll, scrub, pinning and refresh |
| [gsap-timeline](library/gsap-timeline.md) | Sequencing, labels, position and playback |
| [gsap-utils](library/gsap-utils.md) | Mapping, interpolation, snapping and helpers |

<a id="plugins"></a>
## Framer plugins

| Module | Use for |
|---|---|
| [framer-plugins](library/framer-plugins.md) | Plugin development only, not paste-ready components |
| [framer-plugins-api-reference](library/framer-plugins-api-reference.md) | Plugin API lookup |
| [framer-plugins-patterns](library/framer-plugins-patterns.md) | Plugin implementation patterns |
| [framer-plugins-pitfalls](library/framer-plugins-pitfalls.md) | Plugin errors and constraints |

The eight GSAP modules are from [GreenSock’s official skill repository](https://github.com/greensock/gsap-skills). [Source and license details](../ATTRIBUTION.md).
